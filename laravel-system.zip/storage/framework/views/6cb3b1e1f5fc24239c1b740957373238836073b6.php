<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        Developed by <a href="<?php echo e(config('app.company_web')); ?>"><?php echo e(config('app.company_name')); ?></a>
    </div>
    <!-- Default to the left -->
    <strong><i class="far fa-copyright"></i> <?php echo e(date('Y')); ?> <a href="<?php echo e(config('app.client_web')); ?>"><?php echo e(config('app.client_name')); ?></a></strong>
</footer>
<?php /**PATH /home/kevin/Development/dealer-recommendation-point/resources/views/dashboard/partials/footer.blade.php ENDPATH**/ ?>