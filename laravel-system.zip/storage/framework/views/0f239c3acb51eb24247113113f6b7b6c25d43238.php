<?php
$sidebarMenu = \App\Http\Controllers\Dashboard::sidebarMenu();
$segment = request()->segments();
?>

<!-- Brand Logo -->
<a href="<?php echo e(url('/')); ?>" class="brand-link">
    <img src="<?php echo e(asset('img/AdminLTELogo.png')); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light"><?php echo e(config('app.app_name_small')); ?></span>
</a>

<!-- Sidebar -->
<div class="sidebar">
    <!-- Sidebar user panel (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
            <div class="img-circle" style="font-size: 25px; color: Dodgerblue;">
                <i class="fas fa-user-circle"></i>
            </div>
        </div>
        <div class="info">
            <a href="<?php echo e(url('master-data/profile')); ?>" class="d-block">
                <strong class="text-uppercase">
                    <?php echo e(\Illuminate\Support\Facades\Session::get('username')); ?>

                </strong>
            </a>
        </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <li class="nav-item">
                <a href="<?php echo e(url('/')); ?>" class="nav-link">
                    <i class="nav-icon fas fa-th"></i>
                    <p>Home</p>
                </a>
            </li>
            <!-- Add icons to the links using the .nav-icon class
                 with font-awesome or any other icon font library -->
            <?php $__currentLoopData = $sidebarMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $menuOpen = '';
                    $groupActive = '';
                    if (isset($segment[0]) && $segment[0] == $sm['group']['segment_name']) {
                        $menuOpen = 'menu-open';
                        $groupActive = 'active';
                    }
                ?>
                <li class="nav-item has-treeview <?php echo e($menuOpen); ?>">
                    <a href="#" class="nav-link <?php echo e($groupActive); ?>">
                        <i class="nav-icon <?php echo e($sm['group']['icon']); ?>"></i>
                        <p>
                            <?php echo e($sm['group']['nama']); ?>

                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <?php $__currentLoopData = $sm['menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <?php
                                $status = '';
                                if (isset($segment[1]) && $segment[1] == $m['segment_name']) {
                                    $status = 'active';
                                }
                                ?>
                                <a href="<?php echo e(url($m['url'])); ?>" class="nav-link <?php echo e($status); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p><?php echo e($m['nama']); ?></p>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </nav>
    <!-- /.sidebar-menu -->
</div>
<!-- /.sidebar -->
<?php /**PATH /home/kevin/Development/dealer-recommendation-point/resources/views/dashboard/partials/sidebar.blade.php ENDPATH**/ ?>