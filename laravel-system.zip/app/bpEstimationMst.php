<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bpEstimationMst extends Model
{
    //
}
