<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bookingGrTrn extends Model
{
    //
}
