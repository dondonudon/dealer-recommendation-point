<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ms_sales extends Model
{
    protected $table = 'ms_salesman';

    protected $fillable = ['username'];
}
